SELECT  *FROM Product
SELECT  *FROM  Users
SELECT  *FROM Orders
SELECT  *FROM Discount
SELECT  *FROM OrderItem
-- ================================================
-- Template generated from Template Explorer using:
-- Create Procedure (New Menu).SQL
--
-- Use the Specify Values for Template Parameters 
-- command (Ctrl-Shift-M) to fill in the parameter 
-- values below.
--
-- This block of comments will not be included in
-- the definition of the procedure.
-- ================================================
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Parth Panchal>
-- Create date: <2022-07-08>
-- Description:	<SP>
-- =============================================
CREATE PROCEDURE sp_order
	-- Add the parameters for the stored procedure here
	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	DECLARE @StudentData NVARCHAR(MAX)
SET @StudentData = N'[
{"ProductID":"4","UserID":"2","Qty":"2","OrderDate":"2022-07-08"},
{"ProductID":"3","UserID":"2","Qty":"2","OrderDate":"2022-07-08"}
]';

SELECT ProductID,UserID,Qty,OrderDate FROM OPENJSON(@StudentData)
WITH (
ProductID INT '$.ProductID',
UserID INT '$.UserID',
Qty INT '$.Qty',
OrderDate Date '$.OrderDate'


);

    -- Insert statements for procedure here

END
GO
EXEC sp_order
------------------------------------------------------------------insert the record in the order and orderitem table------------------------

-----------------FUNCTION FOR calculate OrderAmount based ProductPrice and Qty------
CREATE FUNCTION calculate(@price INT,@qty INT)
RETURN INT
AS
BEGIN 
DECLARE @OrderAmount INT
--SELECT P.Price , O.Qty FROM Product P JOIN OrderItem O ON P.ProductID = O.ProductID
RETURN(@price*@qty)

END


-- ================================================
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Parth Panchal>
-- Create date: <2022-07-08>
-- Description:	<SP>
-- =============================================
CREATE PROCEDURE sp_orders
	-- Add the parameters for the stored procedure here
	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	DECLARE @StudentData NVARCHAR(MAX)
SET @StudentData = N'[
{"Student_name":"Parth","Address":"Anand","City":"Anand","DOB":"2000-01-09","Standard":"8th"},
{"Student_name":"Krutik","Address":"Anand","City":"Anand","DOB":"2000-01-09","Standard":"8th"},
{"Student_name":"Stuti","Address":"Ahmedabad","City":"Ahmedababd","DOB":"2000-01-09","Standard":"8th"},
{"Student_name":"Keyuri","Address":"Porbandar","City":"Ahmedababd","DOB":"2000-01-09","Standard":"8th"},
{"Student_name":"Chaitanya","Address":"Jamnanager","City":"Ahmedababd","DOB":"2000-01-09","Standard":"8th"}
]';

SELECT Student_Name,Address,City,DOB,Standard FROM OPENJSON(@StudentData)
WITH (
Student_name varchar(50) '$.Student_name',
Address Nvarchar(50) '$.Address',
City varchar(50) '$.City',
DOB NVarchar(50) '$.DOB',
Standard NVARCHAR(50) '$.Standard'

);

    -- Insert statements for procedure here

END
GO
