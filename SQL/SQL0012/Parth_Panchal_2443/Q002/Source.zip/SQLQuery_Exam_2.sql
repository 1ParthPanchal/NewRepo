SELECT  *FROM Product
SELECT  *FROM  Users
SELECT  *FROM Orders
SELECT  *FROM Discount
SELECT  *FROM OrderItem

---------------------1------------------------------
CREATE VIEW ord_prr AS SELECT P.ProductID AS 'P_ID' FROM Product P JOIN OrderItem O On P.ProductID=O.ProductID  WHERE P.ProductID NOT IN(1,2,3,4)
Select * FROM ord_prr
--------------------------2--------------------------
CREATE VIEW dis AS SELECT P.ProductID  AS 'P_ID' FROM Product P JOIN Discount D On P.ProductID=D.ProductID WHERE P.ProductID NOT IN(1,2,3,4)
SELECT * FROM dis
----------------------------3--------------------------------
----------4--------------------
CREATE VIEW reportt AS SELECT O.OrderID, U.Username,P.Name ,O.DiscountAmount AS 'Discount', O.OrderAmount, O.PayableAmount FROM Orders O JOIN Users U ON O.UserID=U.UserId JOIN Product P on P.ProductID = U.UserID
SELECT * FROM reportt