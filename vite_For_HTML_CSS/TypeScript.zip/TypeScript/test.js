var fruits = ['A' , 'Orange' , 'Banana'];
fruits.sort();
console.log(fruits);

console.log(fruits.pop());

fruits.push("Apple");
console.log(fruits);

fruits = fruits.concat(['Mango' , 'Greps']);
console.log(fruits);

console.log(fruits.indexOf("Apple"));

var newArray = fruits.filter((fruits,i,arr) => {
    return fruits.length<2
})

console.log(newArray);

