export
let str1 : string = "Hello";
let str2 : string = "How are you";
let str3 : string = "My name is Parth";

let Name : string = `${str1} + ${str2} + ${str3}`;
console.log(Name);
console.log(str1.charAt(2));
console.log(str1.concat(str2,str3));
console.log(str3.indexOf("y"));
console.log(str2.replace("How are you" , "I am Fine"));
console.log(str1.split(','));
console.log(str1.toUpperCase());
console.log(str2.toLowerCase());







