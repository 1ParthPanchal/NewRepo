let arr = ["Parth", 22, true];
arr.push("Panchal");
console.log(arr);
