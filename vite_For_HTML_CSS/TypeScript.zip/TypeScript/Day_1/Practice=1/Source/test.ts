var fruits : Array<string | number> = ['A' ,2 ,  'Orange' ,3 , 4 ,  'Banana'];
fruits.sort();
console.log(fruits);

console.log(fruits.pop());

fruits.push("Apple");
console.log(fruits);

fruits = fruits.concat(['Mango' , 'Greps']);
console.log(fruits);

console.log(fruits.indexOf("Apple"));

var newArray = fruits.filter((fruits,i,arr) => {
    return fruits<7
})

console.log(newArray);

for(var index in fruits){
    console.log(fruits[index]);
    
}
for(let i = 0; i<fruits.length ; i++){
    console.log(fruits[i]);
    
}
for (var value of fruits){
    console.log(value);
    
}
