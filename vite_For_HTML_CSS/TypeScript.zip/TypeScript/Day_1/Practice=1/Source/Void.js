function helloUser() {
    alert("Hello All");
    document.write("Hello All");
}
console.log("Hello");

