var   Name :string = "Parth";
var age : number = 22;
console.log(Name);
console.log(age);

