export{}
function helloUser() : void{
    alert("Hello All");
    document.write("Hello All");
}
console.log("Hello");
