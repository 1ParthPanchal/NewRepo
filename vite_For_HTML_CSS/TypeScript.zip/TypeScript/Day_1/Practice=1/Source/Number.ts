let First : number = 123;
let second : number = 0x123;
let third : number = 0o377;
let forth : number = 0b111001;
let five : number = 0o57;
let six : number = 1234;
console.log(First.toExponential(2));
console.log(second.toFixed(2));
console.log(third.toLocaleString('ar-EG'));
console.log(forth.toPrecision(1));
console.log(five.toString(36));
console.log(six.valueOf());



 // First.toExponential(2);



