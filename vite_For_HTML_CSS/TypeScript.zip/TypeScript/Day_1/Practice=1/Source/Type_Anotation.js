var Name = "Parth";
var age = 22;
console.log(Name);
console.log(age);
